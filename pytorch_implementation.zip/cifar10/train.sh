python main.py --affix std
python main.py --affix linf --adv_train -p linf -e 0.0157